#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:56:22 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_PickUpCountSetting_type.BP_STRUCT_PickUpCountSetting_type
// 0x0008
struct FBP_STRUCT_PickUpCountSetting_type
{
	int                                                ItemID_0_545B594077C2AB55279AB97B0BD162B4;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                PickUpMaxCount_1_7F45D10069EF87FA21D7CBCA0C4BDCD4;        // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

