#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:56:26 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_UGCDelayPublishConfig_type.BP_STRUCT_UGCDelayPublishConfig_type
// 0x0050
struct FBP_STRUCT_UGCDelayPublishConfig_type
{
	int                                                AssetID_0_090D47806B340C5C5C00CB1409B0E164;               // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ID_1_60C867805D709E046D552A1901929BC4;                    // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     OpenDate_2_510CE84021F8F50171F88D14073034D5;              // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                DelayType_3_11B5288025476E1C029A581C0BA71BD5;             // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                IsIconTimerShown_4_3698D9805D5659C2294AF5E700A66C8E;      // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     ExpiredDate_6_4C5158004372B326409AD15601055885;           // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                IsResourceAllowedInPak_7_25572C006841D8740890B1C80CF6312B;// 0x0030(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                AuthorizedAsset_8_058A6C006ECAA5684492C4230857E314;       // 0x0034(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     ExpiredFeatureKeys_9_2014F280694823F015140AAF0CDBA7A3;    // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ExclusiveIPTemplateID_10_42D08AC058C9985956C32BF90FD83EA4;// 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                IsSaveToPrefabMallForbidden_11_0C3FC0805D2832102DD940F80CE2021E;// 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

