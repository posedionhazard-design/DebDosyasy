#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:56:25 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_LoginHideCfg_type.BP_STRUCT_LoginHideCfg_type
// 0x0020
struct FBP_STRUCT_LoginHideCfg_type
{
	struct FString                                     Channel_0_7A33B4804EECE9DA2882EE5B0C6EAD0C;               // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FName>                               Rule_an_1_760777C07100CED14B793A7D0C488CDE;               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

