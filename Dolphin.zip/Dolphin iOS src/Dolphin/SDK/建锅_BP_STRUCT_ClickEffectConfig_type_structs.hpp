#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:56:25 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_ClickEffectConfig_type.BP_STRUCT_ClickEffectConfig_type
// 0x0024
struct FBP_STRUCT_ClickEffectConfig_type
{
	struct FString                                     EffectPath_0_2ACF9E403A99485B3FF38FDA0B1B17F8;            // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ItemID_1_5E680EC04AABA6193990931003C93164;                // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ClickCD_f_2_0396F440074FE7E525BA100706946046;             // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PreviewScaleRatio_f_3_45088B405CB8E50B1432563F0FA64306;   // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              UsedScaleRatio_f_4_2BF3F7003E59C24A198A433101A08DD6;      // 0x001C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              PreviewCD_f_5_424533405FC3531F6560BF1904F0CD96;           // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

