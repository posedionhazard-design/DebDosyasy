#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:56:25 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_UGCAssetParamCfg_type.BP_STRUCT_UGCAssetParamCfg_type
// 0x0054
struct FBP_STRUCT_UGCAssetParamCfg_type
{
	int                                                ID_0_2507A0C05540DF930795EF7E09DEA774;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ResID_1_4A560B406D40F7AF77498BFE0A625A34;                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ResType_3_46C4B08010363AD65513A91F02556A05;               // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FString                                     DependAssetIDs_5_5D2A31801772B9843E1D734E0F2A6233;        // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     DependFeatureKeys_7_24B66B800AE1CD080D6F1416027700D3;     // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PoolAssetArray_8_5E8803C05CB93B274979C8150116B4C9;        // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PreloadAssetArray_9_0B824F000BD351EE2B4DC8EE039D05C9;     // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                PackID_10_5F35A0802628AD6C7553DD5B06CE4174;               // 0x0050(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

