#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:56:09 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Enums
//---------------------By 建锅 @JGNB_K---------------------------

// Enum PixUIProfiler.EPxProfilerCapability
enum class EPxProfilerCapability : uint8_t
{
	EPxProfilerCapability__PrintSizeChange = 0,
	EPxProfilerCapability__PrintCountChange = 1,
	EPxProfilerCapability__AsyncInnerData = 2,
	EPxProfilerCapability__Count   = 3,
	EPxProfilerCapability__EPxProfilerCapability_MAX = 4
};



}

