#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:55:05 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Enums
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedEnum Common_Button_Type_Enum.Common_Button_Type_Enum
enum class ECommon_Button_Type_Enum : uint8_t
{
	Common_Button_Type_Enum__NewEnumerator2 = 0,
	Common_Button_Type_Enum__NewEnumerator3 = 1,
	Common_Button_Type_Enum__NewEnumerator1 = 2,
	Common_Button_Type_Enum__NewEnumerator0 = 3,
	Common_Button_Type_Enum__NewEnumerator5 = 4,
	Common_Button_Type_Enum__NewEnumerator6 = 5,
	Common_Button_Type_Enum__NewEnumerator10 = 6,
	Common_Button_Type_Enum__Common_Button_Type_MAX = 7
};



}

