#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:55:06 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Parameters
//---------------------By 建锅 @JGNB_K---------------------------

// Function Lua_Common_Button.Lua_Common_Button_C.SetEnumButtonType
struct ULua_Common_Button_C_SetEnumButtonType_Params
{
};

// Function Lua_Common_Button.Lua_Common_Button_C.GetPreviewPath
struct ULua_Common_Button_C_GetPreviewPath_Params
{
	struct FString                                     BPPath;                                                   // (Parm, OutParm, ZeroConstructor)
};

// Function Lua_Common_Button.Lua_Common_Button_C.ConstructPreviewSubItem
struct ULua_Common_Button_C_ConstructPreviewSubItem_Params
{
};

// Function Lua_Common_Button.Lua_Common_Button_C.PreConstruct
struct ULua_Common_Button_C_PreConstruct_Params
{
	bool*                                              IsDesignTime;                                             // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Lua_Common_Button.Lua_Common_Button_C.ExecuteUbergraph_Lua_Common_Button
struct ULua_Common_Button_C_ExecuteUbergraph_Lua_Common_Button_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

