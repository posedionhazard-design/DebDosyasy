// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:55:07 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Functions
//---------------------By 建锅 @JGNB_K---------------------------

// Function Common_Button_Primary_Recommend_UIBP.Common_Button_Primary_Recommend_UIBP_C.PreConstruct
// (BlueprintCosmetic, Event, Public, BlueprintEvent)
// Parameters:
// bool*                          IsDesignTime                   (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UCommon_Button_Primary_Recommend_UIBP_C::PreConstruct(bool* IsDesignTime)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_Button_Primary_Recommend_UIBP.Common_Button_Primary_Recommend_UIBP_C.PreConstruct");

	UCommon_Button_Primary_Recommend_UIBP_C_PreConstruct_Params params;
	params.IsDesignTime = IsDesignTime;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Common_Button_Primary_Recommend_UIBP.Common_Button_Primary_Recommend_UIBP_C.ExecuteUbergraph_Common_Button_Primary_Recommend_UIBP
// ()
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void UCommon_Button_Primary_Recommend_UIBP_C::ExecuteUbergraph_Common_Button_Primary_Recommend_UIBP(int EntryPoint)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_Button_Primary_Recommend_UIBP.Common_Button_Primary_Recommend_UIBP_C.ExecuteUbergraph_Common_Button_Primary_Recommend_UIBP");

	UCommon_Button_Primary_Recommend_UIBP_C_ExecuteUbergraph_Common_Button_Primary_Recommend_UIBP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

