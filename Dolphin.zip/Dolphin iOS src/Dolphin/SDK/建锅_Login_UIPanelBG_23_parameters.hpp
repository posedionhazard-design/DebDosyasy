#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.4.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Mon May 11 21:56:25 2026
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Parameters
//---------------------By 建锅 @JGNB_K---------------------------

// Function Login_UIPanelBG_23.Login_UIPanelBG_22_C.Construct
struct ULogin_UIPanelBG_22_C_Construct_Params
{
};

// Function Login_UIPanelBG_23.Login_UIPanelBG_22_C.Tick
struct ULogin_UIPanelBG_22_C_Tick_Params
{
	struct FGeometry*                                  MyGeometry;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData)
	float*                                             InDeltaTime;                                              // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function Login_UIPanelBG_23.Login_UIPanelBG_22_C.ExecuteUbergraph_Login_UIPanelBG_23
struct ULogin_UIPanelBG_22_C_ExecuteUbergraph_Login_UIPanelBG_23_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

